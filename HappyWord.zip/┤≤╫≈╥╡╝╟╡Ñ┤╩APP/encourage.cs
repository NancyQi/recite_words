﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 大作业记单词APP
{
    public partial class encourage : Form
    {
        public encourage()
        {
            InitializeComponent();
            pictureBox1.Image = Image.FromFile(".\\encourage.PNG");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            timer1.Interval = 1000;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        int i = 2;
        int j = 0;
        private void encourage_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (j < i)
            {
                j++;
            }
            else if (j == 2)
            {
                timer1.Stop();
                this.Close();

            }
            else
            {
                timer1.Stop();
                this.Close();
            }
        }
    }
}
