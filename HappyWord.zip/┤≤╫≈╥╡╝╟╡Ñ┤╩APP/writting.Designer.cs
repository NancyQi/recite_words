﻿namespace 大作业记单词APP
{
    partial class Writting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Writting));
            this.word = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.judge = new System.Windows.Forms.Label();
            this.already = new System.Windows.Forms.Button();
            this.submit = new System.Windows.Forms.Button();
            this.next = new System.Windows.Forms.Button();
            this.addToNote = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // word
            // 
            this.word.AutoSize = true;
            this.word.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.word.Location = new System.Drawing.Point(204, 239);
            this.word.Name = "word";
            this.word.Size = new System.Drawing.Size(0, 33);
            this.word.TabIndex = 0;
            this.word.Click += new System.EventHandler(this.word_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(210, 327);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 28);
            this.textBox1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 18);
            this.label2.TabIndex = 3;
            // 
            // judge
            // 
            this.judge.AutoSize = true;
            this.judge.Location = new System.Drawing.Point(587, 184);
            this.judge.Name = "judge";
            this.judge.Size = new System.Drawing.Size(0, 18);
            this.judge.TabIndex = 4;
            // 
            // already
            // 
            this.already.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.already.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("already.BackgroundImage")));
            this.already.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.already.FlatAppearance.BorderSize = 0;
            this.already.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.already.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.already.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.already.Location = new System.Drawing.Point(269, 392);
            this.already.Margin = new System.Windows.Forms.Padding(0);
            this.already.Name = "already";
            this.already.Size = new System.Drawing.Size(130, 79);
            this.already.TabIndex = 6;
            this.already.UseVisualStyleBackColor = false;
            this.already.Click += new System.EventHandler(this.already_Click);
            // 
            // submit
            // 
            this.submit.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.submit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("submit.BackgroundImage")));
            this.submit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.submit.FlatAppearance.BorderSize = 0;
            this.submit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.submit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.submit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.submit.Location = new System.Drawing.Point(357, 290);
            this.submit.Margin = new System.Windows.Forms.Padding(0);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(128, 78);
            this.submit.TabIndex = 7;
            this.submit.UseVisualStyleBackColor = false;
            this.submit.Click += new System.EventHandler(this.submit_Click);
            // 
            // next
            // 
            this.next.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.next.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("next.BackgroundImage")));
            this.next.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.next.FlatAppearance.BorderSize = 0;
            this.next.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.next.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.next.Location = new System.Drawing.Point(269, 488);
            this.next.Margin = new System.Windows.Forms.Padding(0);
            this.next.Name = "next";
            this.next.Size = new System.Drawing.Size(128, 79);
            this.next.TabIndex = 8;
            this.next.UseVisualStyleBackColor = false;
            this.next.Click += new System.EventHandler(this.next_Click);
            // 
            // addToNote
            // 
            this.addToNote.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("addToNote.BackgroundImage")));
            this.addToNote.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.addToNote.FlatAppearance.BorderSize = 0;
            this.addToNote.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.addToNote.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.addToNote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addToNote.Location = new System.Drawing.Point(269, 589);
            this.addToNote.Margin = new System.Windows.Forms.Padding(0);
            this.addToNote.Name = "addToNote";
            this.addToNote.Size = new System.Drawing.Size(130, 79);
            this.addToNote.TabIndex = 9;
            this.addToNote.UseVisualStyleBackColor = true;
            this.addToNote.Click += new System.EventHandler(this.addToNote_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(129, 580);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(71, 71);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(470, 571);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(71, 71);
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(126, 670);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 18);
            this.label5.TabIndex = 14;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(479, 661);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 18);
            this.label3.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(465, 509);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 28);
            this.label4.TabIndex = 17;
            this.label4.Text = "星星数";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(301, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 18);
            this.label1.TabIndex = 18;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(210, 149);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(100, 23);
            this.progressBar1.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(207, 193);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 18);
            this.label6.TabIndex = 20;
            // 
            // Writting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(708, 1050);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.addToNote);
            this.Controls.Add(this.next);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.already);
            this.Controls.Add(this.judge);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.word);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Writting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "writting";
            this.Load += new System.EventHandler(this.Writting_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label word;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label judge;
        private System.Windows.Forms.Button already;
        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.Button addToNote;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label label6;
    }
}