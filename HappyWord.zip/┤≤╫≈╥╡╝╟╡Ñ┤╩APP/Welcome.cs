﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 大作业记单词APP
{
    public partial class Welcome : Form
    {
        Account account0;
        public Welcome(Account account)
        {
            InitializeComponent();
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
            account0 = account;
        }

        Account account1 = new Account();
        private void Welcome_Load(object sender, EventArgs e)
        {
            this.label1.Text = "欢迎你，用户" + account0.Name;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MakePlan makePlan = new MakePlan(account0);
            makePlan.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Review_choose_part review = new Review_choose_part(account0);
            review.Show();
        }

        private void search_Click(object sender, EventArgs e)
        {
            Search search = new Search();
            search.Show();
        }

    }
}
