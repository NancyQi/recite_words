﻿namespace 大作业记单词APP
{
    partial class Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Search));
            this.searchingBox = new System.Windows.Forms.TextBox();
            this.beginSearch = new System.Windows.Forms.Button();
            this.searched = new System.Windows.Forms.Label();
            this.addToNote = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // searchingBox
            // 
            this.searchingBox.Location = new System.Drawing.Point(201, 175);
            this.searchingBox.Name = "searchingBox";
            this.searchingBox.Size = new System.Drawing.Size(183, 28);
            this.searchingBox.TabIndex = 0;
            // 
            // beginSearch
            // 
            this.beginSearch.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.beginSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("beginSearch.BackgroundImage")));
            this.beginSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.beginSearch.FlatAppearance.BorderSize = 0;
            this.beginSearch.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.beginSearch.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.beginSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.beginSearch.Location = new System.Drawing.Point(437, 158);
            this.beginSearch.Margin = new System.Windows.Forms.Padding(0);
            this.beginSearch.Name = "beginSearch";
            this.beginSearch.Size = new System.Drawing.Size(131, 78);
            this.beginSearch.TabIndex = 2;
            this.beginSearch.UseVisualStyleBackColor = false;
            this.beginSearch.Click += new System.EventHandler(this.beginSearch_Click);
            // 
            // searched
            // 
            this.searched.AutoSize = true;
            this.searched.Location = new System.Drawing.Point(198, 278);
            this.searched.Name = "searched";
            this.searched.Size = new System.Drawing.Size(0, 18);
            this.searched.TabIndex = 3;
            // 
            // addToNote
            // 
            this.addToNote.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("addToNote.BackgroundImage")));
            this.addToNote.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.addToNote.FlatAppearance.BorderSize = 0;
            this.addToNote.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.addToNote.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.addToNote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addToNote.Location = new System.Drawing.Point(266, 465);
            this.addToNote.Margin = new System.Windows.Forms.Padding(0);
            this.addToNote.Name = "addToNote";
            this.addToNote.Size = new System.Drawing.Size(162, 98);
            this.addToNote.TabIndex = 10;
            this.addToNote.UseVisualStyleBackColor = true;
            // 
            // Search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(708, 844);
            this.Controls.Add(this.addToNote);
            this.Controls.Add(this.searched);
            this.Controls.Add(this.beginSearch);
            this.Controls.Add(this.searchingBox);
            this.Name = "Search";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search";
            this.Load += new System.EventHandler(this.Search_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox searchingBox;
        private System.Windows.Forms.Button beginSearch;
        private System.Windows.Forms.Label searched;
        private System.Windows.Forms.Button addToNote;
    }
}