﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 大作业记单词APP
{
    public partial class PunchIn : Form
    {
        Account account0;
        public PunchIn(Account account)
        {
            InitializeComponent();
            account0 = account;
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
            Init();
        }

        public void Init()
        {
            label3.Text = account0.punchIn_number.ToString();
        }

        public void punchIn()
        {
            account0.punchIn_number++;

            MessageBox.Show("打卡成功！奖励！");

            label3.Text = account0.punchIn_number.ToString();
        }


        private void Button1_Click(object sender, EventArgs e)
        {
            punchIn();
        }

        private void PunchIn_Load(object sender, EventArgs e)
        {

        }
    }
}
