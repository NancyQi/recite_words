﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 大作业记单词APP
{
    public partial class Register : Form
    {
        Begin begin0;
        public Register(Begin begin)
        {
            InitializeComponent(); 
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
            begin0 = begin;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text.ToString();
            string password0 = textBox2.Text.ToString();
            string password1 = textBox3.Text.ToString();
            if (name == "" || password0 == "" || password1 == "") 
                MessageBox.Show("请检查是否正确输入!!!");
            else
            {
                if(password0 !=password1)
                    MessageBox.Show("两次密码输入有误");
                else
                {
                    Account.addAccount(new Account(name, password0, 0,0));
                    begin0.Visible = true;
                    this.Close();
                }
            }

        }

        private void Register_Load(object sender, EventArgs e)
        {

        }
    }
}
