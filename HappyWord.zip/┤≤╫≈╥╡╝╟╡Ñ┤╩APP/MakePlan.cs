﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 大作业记单词APP
{
    public partial class MakePlan : Form
    {

        Account account0;

        public MakePlan()
        {
            InitializeComponent();
        }

        public MakePlan(Account account)
        {
            InitializeComponent();

            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
            
            account0 = account;
        }


        struct Word
        {
            public string Eng;
            public string Chi;
            public int tag;
        }

        Word[] words;
        SortedDictionary<string, string> dict =
            new SortedDictionary<string, string>();

        public void ReadFour()  //读四级单词
        {
            StreamReader sr = new StreamReader
                (".\\College_Grade4.txt", Encoding.Default);
            //此处要改为新建txt文件

            string cont = sr.ReadToEnd();
            string[] linecont = cont.Split('\n');
            words = new Word[linecont.Length];

            for (int i = 0; i < linecont.Length; i++)
            {
                linecont[i] = linecont[i].Trim();
                string[] line = linecont[i].Split('\t');
                if (line.Length < 2)
                    continue;
                if (!dict.ContainsKey(line[0]))
                {
                    dict.Add(line[0], line[1]);
                }
                words[i].Eng = line[0];
                words[i].Chi = line[1];

                words[i].tag = 1;//整合的时候删掉这行
            }
        }

        public void ReadSix()//读六级单词
        {

        }

        private void RadioButton1_Click(object sender, EventArgs e)
        {
            ReadFour();
            label3.Text = words.Length.ToString();
        }

        int everydayCount = 0;
        int every = 0;
        int day = 100;
        public void sure()
        {
            if (textBox1.Text.Length <= 0)
                MessageBox.Show("未输入计划天数！");

            day = Convert.ToInt32(textBox1.Text);
            every = words.Length / day;
            if (every < 0 || every > 500)
            {
                MessageBox.Show("背单词书不科学，请重新输入！");
                return;
            }
            label7.Text = every.ToString();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            sure();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            everydayCount = every;
            string str = "每日背单词数：" + everydayCount.ToString();
            MessageBox.Show(str);

            account0.plan_number = everydayCount;
        }

        private void MakePlan_Load(object sender, EventArgs e)
        {

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            Remember remember = new Remember(account0);
            remember.Show();
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
