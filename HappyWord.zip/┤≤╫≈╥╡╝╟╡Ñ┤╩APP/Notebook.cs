﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 大作业记单词APP
{
    public partial class Notebook : Form
    {
        public string bookname = "";
        public Notebook()
        {
            InitializeComponent();
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
        }

        private void content_Click(object sender, EventArgs e)
        {

        }

        private void name_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            name.Text = bookname;
            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
            con.Open();
            string sql = string.Format("select* from " + bookname);
            SqlDataAdapter sad = new SqlDataAdapter(sql, con);
            DataSet s = new DataSet();
            sad.Fill(s);
            con.Close();
            DataTable t = s.Tables[0];
            foreach (DataRow row in t.Rows)
            {
                content.Text = (row["english"]).ToString() + (row["chinese"]).ToString() + "\n";
            }
        }

        private void Notebook_Load(object sender, EventArgs e)
        {

        }
    }
}
