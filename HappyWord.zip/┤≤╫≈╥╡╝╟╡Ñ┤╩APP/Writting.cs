﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 大作业记单词APP
{
    public partial class Writting : Form
    {
        Account account0;
        
        public Writting(Account account)
        {
            InitializeComponent();
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
            account0 = account;
            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
            con.Open();
            string sql = string.Format("select* from review");
            SqlDataAdapter sad = new SqlDataAdapter(sql, con);
            DataTable t = new DataTable();
            sad.Fill(t);
            //MessageBox.Show((t.Rows.Count).ToString());
            //&& (int)(t.Rows)[thiscount]["tag"] <= 5
            if (thiscount < t.Rows.Count )
            {
                word.Text = (string)((t.Rows)[thiscount]["chinese"]);
            }
            con.Close();

        }
        int thiscount = 0;

        int count = 0;
        int time = 8;
        int starnumber = 0;

        //学会就过
        private void already_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
            con.Open();
            string sql = string.Format("update review set tag=5 where chinese='{0}' and english='{1}'", this.label2.Text, this.label1.Text);
            SqlCommand sqlc = new SqlCommand(sql, con);
            int result = 0;
            try
            {
                result = sqlc.ExecuteNonQuery();
                if (result == 1)
                {
                }
                else
                {
                }
            }
            catch
            {
                MessageBox.Show("更新失败");
            }
        }
        
        private void next_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
            con.Open();
            string sql = string.Format("select* from review");
            SqlDataAdapter sad = new SqlDataAdapter(sql, con);
            DataTable t = new DataTable();
            sad.Fill(t);
            changeProgressBar();
            //MessageBox.Show((t.Rows.Count).ToString());
            if (thiscount < t.Rows.Count&&(int)(t.Rows)[thiscount]["tag"]<=5)
            {  
                word.Text = (string)((t.Rows)[thiscount]["chinese"]);
            }
            con.Close();
            textBox1.Text = " ";
            judge.Text = " ";
           

         
            
            label3.Text = starnumber.ToString();
            count++;
            timer1.Start();
            count = 0;
            time = 8;
        }

        private void submit_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
            con.Open();
            string sql = string.Format("select* from review");
            SqlDataAdapter sad = new SqlDataAdapter(sql, con);
            DataTable t = new DataTable();
            sad.Fill(t);
            //MessageBox.Show((t.Rows.Count).ToString());
            if (textBox1.Text== (string)((t.Rows)[thiscount]["english"]) && count < 2)
            {
                judge.Text = "√";
                encourage3 form2 = new encourage3();
                form2.ShowDialog();

                this.timer1.Stop();
                starnumber += 3;
                //得到当前tag
                string sqln = string.Format("select * from review where chinese='{0}' and english='{1}'", this.label2.Text, this.label1.Text);
                SqlCommand command = new SqlCommand(sqln, con);
                SqlDataReader reader = command.ExecuteReader();
                int thistag=0;
                while (reader.Read())
                {
                    thistag = (int)reader["tag"];
                }
                reader.Close();
                //更新tag
                string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'", thistag+1,this.label2.Text, this.label1.Text);
                SqlCommand sqlc = new SqlCommand(sqlm, con);
                int result = 0;
                try
                {
                    result = sqlc.ExecuteNonQuery();
                    if (result == 1)
                    {
                    }
                    else
                    {
                    }
                }
                catch
                {
                    MessageBox.Show("添加失败");
                }
                thiscount++;

            }
            else if (textBox1.Text == (string)((t.Rows)[thiscount]["english"]) && count >= 2 && count < 4)
            {
                judge.Text = "√";
                encourage2 form3 = new encourage2();
                form3.ShowDialog();

                this.timer1.Stop();
                starnumber += 3;
                //得到当前tag
                string sqln = string.Format("select * from review where chinese='{0}' and english='{1}'", this.label2.Text, this.label1.Text);
                SqlCommand command = new SqlCommand(sqln, con);
                SqlDataReader reader = command.ExecuteReader();
                int thistag = 0;
                while (reader.Read())
                {
                    thistag = (int)reader["tag"];
                }
                reader.Close();
                //更新tag
                string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'", thistag + 1, this.label2.Text, this.label1.Text);
                SqlCommand sqlc = new SqlCommand(sqlm, con);
                int result = 0;
                try
                {
                    result = sqlc.ExecuteNonQuery();
                    if (result == 1)
                    {
                    }
                    else
                    {
                    }
                }
                catch
                {
                    MessageBox.Show("添加失败");
                }
                thiscount++;
            }
            else if (textBox1.Text == (string)((t.Rows)[thiscount]["english"])&&count < 6 && count >= 4)
            {
                judge.Text = "√";
                encourage1 form4 = new encourage1();
                form4.ShowDialog();

                this.timer1.Stop();
                starnumber += 3;
                //得到当前tag
                string sqln = string.Format("select * from review where chinese='{0}' and english='{1}'", this.label2.Text, this.label1.Text);
                SqlCommand command = new SqlCommand(sqln, con);
                SqlDataReader reader = command.ExecuteReader();
                int thistag = 0;
                while (reader.Read())
                {
                    thistag = (int)reader["tag"];
                }
                reader.Close();
                //更新tag
                string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'", thistag + 1, this.label2.Text, this.label1.Text);
                SqlCommand sqlc = new SqlCommand(sqlm, con);
                int result = 0;
                try
                {
                    result = sqlc.ExecuteNonQuery();
                    if (result == 1)
                    {
                    }
                    else
                    {
                    }
                }
                catch
                {
                    MessageBox.Show("添加失败");
                }
                thiscount++;
            }
            else
            {
                judge.Text = "×";
                encourage form5 = new encourage();
                form5.ShowDialog();
                this.timer1.Stop();

                string sqln = string.Format("select * from review where chinese='{0}' and english='{1}'", this.label2.Text, this.label1.Text);
                SqlCommand command = new SqlCommand(sqln, con);
                SqlDataReader reader = command.ExecuteReader();
                int thistag=0;
                while (reader.Read())
                {
                    thistag = (int)reader["tag"];
                }
                //更新tag
                reader.Close();
                string sqlm = string.Format("update review set tag={0} where chinese='{1}'and english='{2}'", thistag - 1, this.label2.Text, this.label1.Text);
                SqlCommand sqlc = new SqlCommand(sqlm, con);
                int result = 0;
                try
                {
                    result = sqlc.ExecuteNonQuery();
                    if (result == 1)
                    {
                    }
                    else
                    {
                    }
                }
                catch
                {
                    MessageBox.Show("添加失败");
                }
                thiscount++;
            }
            con.Close();
        }

        
        private void addToNote_Click(object sender, EventArgs e)
        {
            Note note=new Note();
            note.Show();
            note.newordenglish = textBox1.Text;
            note.newordchinese = word.Text;
        }

        private void Writting_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(".\\1.jpg");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.Image = Image.FromFile(".\\star.PNG");
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            //设置每隔1秒调用一次定时器Tick事件
            timer1.Interval = 1000;
            progressBar1.Maximum = 20;

            label4.Text = "剩余时间：8秒";
        }

        double pbar = 20.0;
        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (count < time)
            {
                count++;
                label5.Text = "剩余时间：" + (time - count).ToString() + "秒";

            }
            else if (count == time)
            {
                timer1.Stop();
                System.Media.SystemSounds.Asterisk.Play();//提示音
                MessageBox.Show("时间到", "提示", MessageBoxButtons.OKCancel);//提示对话框
            }
            else
            {
                timer1.Stop();
            }
        }

        public void changeProgressBar()
        {
            try
            {
                progressBar1.Value++;
                double x = progressBar1.Value;

                Graphics g = this.progressBar1.CreateGraphics();
                string str = Math.Round(((x - 1) * 100 / pbar), 2).ToString("#0.00 ") + "%";
                Font font = new Font("Times New Roman", (float)10, FontStyle.Regular);
                PointF pt = new PointF(this.progressBar1.Width / 2 - 17, this.progressBar1.Height / 2 - 7);
                g.DrawString(str, font, Brushes.Blue, pt); 
                label6.Text = "已经完成：" + x.ToString() + "  总共：" + pbar.ToString();
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("successs", "完成", MessageBoxButtons.OKCancel);
            }


        }

        private void word_Click(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }
    }
}
