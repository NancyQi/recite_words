﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace 大作业记单词APP
{
    public partial class Search : Form
    {
        struct Word
        {
            public string english;
            public string chinese;
            public int tag;
        }
        //int j = 0;
        Word[] words;
        SortedDictionary<string, string> dict = new SortedDictionary<string, string>();
        //private string[] s1;
        static private FileStream fin = new FileStream(".\\College_Grade4.txt", FileMode.Open, FileAccess.Read);
        static private StreamReader bin = new StreamReader(fin, System.Text.Encoding.Default);
        public Search()
        {
            InitializeComponent();
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
            string cont = bin.ReadToEnd();
            string[] linecont = cont.Split('\n');
            words = new Word[linecont.Length];

            for (int i = 0; i < linecont.Length; i++)
            {
                linecont[i] = linecont[i].Trim();
                string[] line = linecont[i].Split('\t');
                if (line.Length < 2)
                    continue;
                if (!dict.ContainsKey(line[0]))
                {
                    dict.Add(line[0], line[1]);
                }
                words[i].english = line[0];
                words[i].chinese = line[1];

                words[i].tag = 1;
            }
        }

        private void beginSearch_Click(object sender, EventArgs e)
        {
            for(int i=0;i<words.Length;i++)
            {
                if(words[i].english==searchingBox.Text)
                {
                    searched.Text = words[i].chinese;
                }
            }
        }

        private void Search_Load(object sender, EventArgs e)
        {

        }
    }
}
