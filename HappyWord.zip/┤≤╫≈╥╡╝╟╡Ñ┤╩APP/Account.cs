﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace 大作业记单词APP
{
    

    public class Account
    {
        public string Name { get; set; }
        public string Password { get; set; }
        public int Word_number { get; set; }//已学单词数
        public int plan_number { get; set; }//计划学习单词数

        public int punchIn_number { get; set; }//打卡次数
        
        public static List<Account> accounts = new List<Account>();

        public Account()
        {
            this.Name = "";
            this.Password = "";
            this.Word_number = 0;
            this.plan_number = 0;
            this.punchIn_number = 0;
        }
        public Account(string name, string password, int num,int num2)
        {
            this.Name = name;
            this.Password = password;
            this.Word_number = num;
            this.plan_number = num2;
        }
        
        public Account(string name, string password)
        {
            this.Name = name;
            this.Password = password;
            this.Word_number = 0;
            this.plan_number = 0;
        }

        public static void readAccount()
        {
            accounts.Clear();
            StreamReader sr = new StreamReader(".\\Account.txt", Encoding.Default);
            string content = sr.ReadToEnd();//把文件读完存给content
            string[] lines = content.Split('\n');//把读取好的文件分割为一行一行存给数组
            for (int i = 0; i < lines.Length; i++)
            {
                string[] accountss = lines[i].Trim().Split('\t');
                if (accountss.Length < 4)
                    continue;
                accounts.Add(new Account(accountss[0],accountss[1],int.Parse(accountss[2]),int.Parse(accountss[3])));
            }
            sr.Close();
        }

        public static void writeAccount()
        {
            FileStream fs = new FileStream(".\\Account.txt", FileMode.Create,FileAccess.Write);
            fs.SetLength(0);
            StreamWriter sw = new StreamWriter(fs);
            foreach(Account account0 in accounts)
            {
                sw.WriteLine(account0.Name + "\t" + account0.Password + "\t"
                    + account0.Word_number + "\t" + account0.plan_number + "\n");
            }
            sw.Flush();
            sw.Close();
            fs.Close();
        }
        public static void addAccount(Account account)
        {
            readAccount();
            accounts.Add(account);
            writeAccount();
        }
        
        public static Account findAccount(Account account)
        {
            bool flag = false;
            readAccount();
            foreach (Account account0 in accounts)
            {
                if (account.Name == account0.Name && account.Password == account0.Password)
                { 
                    account = account0;
                    flag = true;
                }

            }
            switch (flag)
            {
                case true:
                    return account;
                default:
                    return null;
            }
            
        }

    }

   

}
