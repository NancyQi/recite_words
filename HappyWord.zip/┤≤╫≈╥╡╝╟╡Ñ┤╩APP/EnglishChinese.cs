﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 大作业记单词APP
{
    public partial class EnglishChinese : Form
    {
        Account account0;
        public EnglishChinese()
        {
            InitializeComponent();
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
            //DB
            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
            con.Open();
            string sql = string.Format("select* from review");
            SqlDataAdapter sad = new SqlDataAdapter(sql, con);
            DataTable t = new DataTable();
            sad.Fill(t);
            pbar = t.Rows.Count;
            ReadNewtxt();
            ESelectC();
        }

        int count = 0;
        int time = 8;
        int starnumber = 0;
        public EnglishChinese(Account account)
        {
            InitializeComponent();
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
            account0 = account;
            //DB
            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
            con.Open();
            string sql = string.Format("select* from review");
            SqlDataAdapter sad = new SqlDataAdapter(sql, con);
            DataTable t = new DataTable();
            sad.Fill(t);
            pbar = t.Rows.Count;
            ReadNewtxt();
            ESelectC();
        }



       

        int thiscount = 0;
        int EC;


        public void ReadNewtxt()  //读复习txt文件
        {
        }


        public void ESelectC()//给英文选中文
        { 
            //DB
            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
            con.Open();
            string sql = string.Format("select* from review");
            SqlDataAdapter sad = new SqlDataAdapter(sql, con);
            DataTable t = new DataTable();
            sad.Fill(t);
            label1.Text = (string)((t.Rows)[thiscount]["english"]);

            Random rd = new Random();
            int r0 = rd.Next(4);
            EC = r0;

            switch (r0)
            {
                case 0:
                    radioButton1.Text = (string)((t.Rows)[thiscount]["chinese"]);
                    break;
                case 1:
                    radioButton2.Text = (string)((t.Rows)[thiscount]["chinese"]);
                    break;
                case 2:
                    radioButton3.Text = (string)((t.Rows)[thiscount]["chinese"]);
                    break;
                case 3:
                    radioButton4.Text = (string)((t.Rows)[thiscount]["chinese"]);
                    break;
            }

            int[] rds = new int[3];
           
            //得到当前tag
            rds[0] = rd.Next(t.Rows.Count);
            string sqln = string.Format("select * from review where chinese='{0}' and english='{1}'",
                (string)((t.Rows)[rds[0]]["chinese"]), (string)((t.Rows)[rds[0]]["english"]));
            SqlCommand command = new SqlCommand(sqln, con);
            SqlDataReader reader = command.ExecuteReader();
            int thistag = 0;
            while (reader.Read())
            {
                thistag = (int)reader["tag"];
            }
            reader.Close();
            while (thistag > 5 && rds[0] == r0)
                rds[0] = rd.Next(t.Rows.Count);

            //得到当前tag2
            string sql1 = string.Format("select * from review where chinese='{0}' and english='{1}'",
                (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
            SqlCommand command1 = new SqlCommand(sql1, con);
            SqlDataReader reader1 = command.ExecuteReader();
            int thistag1 = 0;
            while (reader1.Read())
            {
                thistag1 = (int)reader1["tag"];
            }
            reader1.Close();
            rds[1] = rd.Next(t.Rows.Count);
            while (rds[0] == rds[1] && thistag1 > 5 && rds[1] == r0)
                rds[1] = rd.Next(t.Rows.Count);


            //得到当前tag3
            string sql2 = string.Format("select * from review where chinese='{0}' and english='{1}'",
                (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
            SqlCommand command2 = new SqlCommand(sql2, con);
            SqlDataReader reader2 = command.ExecuteReader();
            int thistag2 = 0;
            while (reader2.Read())
            {
                thistag2 = (int)reader2["tag"];
            }
            reader2.Close();
            rds[2] = rd.Next(t.Rows.Count);
            while ((rds[0] == rds[2] || rds[1] == rds[2])
                && thistag2 <=5 && rds[2] == r0)
                rds[2] = rd.Next(t.Rows.Count);


            int[] flags = new int[4] { 0, 0, 0, 0 };
            for (int i = 0; i < 4; i++)
            {
                if (r0 != i)
                {
                    flags[i] = 1;
                }
            }

            if (flags[0] == 1 && flags[1] == 1 &&
                flags[2] == 1 && flags[3] == 0)
            {
                radioButton1.Text = (string)((t.Rows)[rds[0]]["chinese"]);
                radioButton2.Text = (string)((t.Rows)[rds[1]]["chinese"]);
                radioButton3.Text = (string)((t.Rows)[rds[2]]["chinese"]);
            }

            if (flags[0] == 1 && flags[1] == 1 &&
                flags[2] == 0 && flags[3] == 1)
            {
                radioButton1.Text = (string)((t.Rows)[rds[0]]["chinese"]);
                radioButton2.Text = (string)((t.Rows)[rds[1]]["chinese"]);
                radioButton4.Text = (string)((t.Rows)[rds[2]]["chinese"]);
            }

            if (flags[0] == 1 && flags[1] == 0 &&
                flags[2] == 1 && flags[3] == 1)
            {
                radioButton1.Text = (string)((t.Rows)[rds[0]]["chinese"]);
                radioButton3.Text = (string)((t.Rows)[rds[1]]["chinese"]);
                radioButton4.Text = (string)((t.Rows)[rds[2]]["chinese"]);
            }

            if (flags[0] == 0 && flags[1] == 1 &&
                flags[2] == 1 && flags[3] == 1)
            {
                radioButton2.Text = (string)((t.Rows)[rds[0]]["chinese"]);
                radioButton3.Text = (string)((t.Rows)[rds[1]]["chinese"]);
                radioButton4.Text = (string)((t.Rows)[rds[2]]["chinese"]);
            }
            con.Close();
        }


        private void Btnsure_Click(object sender, EventArgs e)
        {
            //DB
            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
            con.Open();
            string sql = string.Format("select* from review");
            SqlDataAdapter sad = new SqlDataAdapter(sql, con);
            DataTable t = new DataTable();
            sad.Fill(t);
            //得到当前tag
            string sqln = string.Format("select * from review where chinese='{0}' and english='{1}'",
                (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
            SqlCommand command = new SqlCommand(sqln, con);
            SqlDataReader reader = command.ExecuteReader();
            int thistag = 0;
            while (reader.Read())
            {
                thistag = (int)reader["tag"];
            }
            reader.Close();
            if (radioButton1.Checked || radioButton2.Checked ||
                radioButton3.Checked || radioButton4.Checked)
            {
                if (EC == 0)
                {
                    if (radioButton1.Checked == true&&count < 2)
                    {
                        label4.Text = "√";
                        encourage3 form2 = new encourage3();
                        form2.ShowDialog();

                        this.timer1.Stop();
                        starnumber += 3;
                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag + 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                    else if (radioButton1.Checked == true && count >= 2 && count < 4)
                    {
                        label4.Text = "√";
                        encourage2 form3 = new encourage2();
                        form3.ShowDialog();
                        this.timer1.Stop();
                        starnumber += 2;
                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag + 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                    else if (radioButton1.Checked == true && count < 6 && count >= 4)
                    {
                        label4.Text = "√";
                        encourage1 form4 = new encourage1();
                        form4.ShowDialog();

                        this.timer1.Stop();
                        starnumber += 1;
                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag + 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                    else
                    {
                        label4.Text = "×";
                        encourage form5 = new encourage();
                        form5.ShowDialog();

                        this.timer1.Stop();

                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag - 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                }
                if (EC == 1)
                {
                    if (radioButton2.Checked == true && count < 2)
                    {
                        label4.Text = "√";
                        encourage3 form2 = new encourage3();
                        form2.ShowDialog();

                        this.timer1.Stop();
                        starnumber += 3;
                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag + 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                    else if (radioButton2.Checked == true && count >= 2 && count < 4)
                    {
                        label4.Text = "√";
                        encourage2 form3 = new encourage2();
                        form3.ShowDialog();
                        this.timer1.Stop();
                        starnumber += 2;
                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag + 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                    else if (radioButton2.Checked == true && count < 6 && count >= 4)
                    {
                        label4.Text = "√";
                        encourage1 form4 = new encourage1();
                        form4.ShowDialog();

                        this.timer1.Stop();
                        starnumber += 1;
                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag + 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                    else
                    {
                        label4.Text = "×";
                        encourage form5 = new encourage();
                        form5.ShowDialog();

                        this.timer1.Stop();

                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag - 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                }
                if (EC == 2)
                {
                    if (radioButton3.Checked == true && count < 2)
                    {
                        label4.Text = "√";
                        encourage3 form2 = new encourage3();
                        form2.ShowDialog();

                        this.timer1.Stop();
                        starnumber += 3;
                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag + 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                    else if (radioButton3.Checked == true && count >= 2 && count < 4)
                    {
                        label4.Text = "√";
                        encourage2 form3 = new encourage2();
                        form3.ShowDialog();
                        this.timer1.Stop();
                        starnumber += 2;
                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag + 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                    else if (radioButton3.Checked == true && count < 6 && count >= 4)
                    {
                        label4.Text = "√";
                        encourage1 form4 = new encourage1();
                        form4.ShowDialog();

                        this.timer1.Stop();
                        starnumber += 1;
                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag + 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                    else
                    {
                        label4.Text = "×";
                        encourage form5 = new encourage();
                        form5.ShowDialog();

                        this.timer1.Stop();

                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag - 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                }
                if (EC == 3)
                {
                    if (radioButton4.Checked == true && count < 2)
                    {
                        label4.Text = "√";
                        encourage3 form2 = new encourage3();
                        form2.ShowDialog();

                        this.timer1.Stop();
                        starnumber += 3;
                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag + 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                    else if (radioButton4.Checked == true && count >= 2 && count < 4)
                    {
                        label4.Text = "√";
                        encourage2 form3 = new encourage2();
                        form3.ShowDialog();
                        this.timer1.Stop();
                        starnumber += 2;
                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag + 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                    else if (radioButton4.Checked == true && count < 6 && count >= 4)
                    {
                        label4.Text = "√";
                        encourage1 form4 = new encourage1();
                        form4.ShowDialog();

                        this.timer1.Stop();
                        starnumber += 1;
                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag + 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                    else
                    {
                        label4.Text = "×";
                        encourage form5 = new encourage();
                        form5.ShowDialog();

                        this.timer1.Stop();

                        //更新tag
                        string sqlm = string.Format("update review set tag={0} where chinese='{1}' and english='{2}'",
                            thistag + 1, (string)((t.Rows)[thiscount]["chinese"]), (string)((t.Rows)[thiscount]["english"]));
                        SqlCommand sqlc = new SqlCommand(sqlm, con);
                        int result = 0;
                        try
                        {
                            result = sqlc.ExecuteNonQuery();
                            if (result == 1)
                            {
                            }
                            else
                            {
                            }
                        }
                        catch
                        {
                            MessageBox.Show("添加失败");
                        }
                        thiscount++;
                    }
                }
            }
            con.Close();
        }//判断正误


        private void Btnnext_Click(object sender, EventArgs e)
        {
            thiscount++;
            ESelectC();
            changeProgressBar();
            label5.Text = starnumber.ToString();
            timer1.Start();
            count = 0;
            time = 8;
            
        }//下一个

        private void Btnjoin_Click(object sender, EventArgs e)
        {
            Note note = new Note();
            note.Show();
            //DB
            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
            con.Open();
            string sql = string.Format("select* from review");
            SqlDataAdapter sad = new SqlDataAdapter(sql, con);
            DataTable t = new DataTable();
            sad.Fill(t);
            //MessageBox.Show((t.Rows.Count).ToString());

            con.Close();
            note.newordenglish = (string)((t.Rows)[thiscount]["english"]);
            note.newordchinese = (string)((t.Rows)[thiscount]["chinese"]);
        }//加入到单词本

        private void EnglishChinese_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(".\\1.jpg");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.Image = Image.FromFile(".\\star.PNG");
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            //设置每隔1秒调用一次定时器Tick事件
            timer1.Interval = 1000;
            progressBar1.Maximum = 20;

            label2.Text = "剩余时间：8秒";
        }

        double pbar = 20.0;
        public void changeProgressBar()
        {
            try
            {
                progressBar1.Value++;
                double x = progressBar1.Value;

                Graphics g = this.progressBar1.CreateGraphics();
                string str = Math.Round(((x - 1) * 100 / pbar), 2).ToString("#0.00 ") + "%";
                Font font = new Font("Times New Roman", (float)10, FontStyle.Regular);
                PointF pt = new PointF(this.progressBar1.Width / 2 - 17, this.progressBar1.Height / 2 - 7);
                g.DrawString(str, font, Brushes.Blue, pt);
                label3.Text = "已经完成：" + x.ToString() + "  总共：" + pbar.ToString();
            }
            


            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("successs", "完成", MessageBoxButtons.OKCancel);
            }

        }//进度条

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (count < time)
            {
                count++;
                label4.Text = "剩余时间：" + (time - count).ToString() + "秒";

            }
            else if (count == time)
            {
                timer1.Stop();
                System.Media.SystemSounds.Asterisk.Play();//提示音
                MessageBox.Show("时间到", "提示", MessageBoxButtons.OKCancel);//提示对话框
            }
            else
            {
                timer1.Stop();
            }

        }

       
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
