﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 大作业记单词APP
{
    public partial class Login : Form
    {
        Begin begin0;
        public Login(Begin begin)
        {
            InitializeComponent();
            begin0 = begin;
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text.ToString();
            string password = textBox2.Text.ToString();
            Account account1 =Account.findAccount( new Account(name,password,0,0));
            if (account1==null)
                MessageBox.Show("用户名不存在或密码错误");
            else
            {
                Welcome welcome = new Welcome(account1);
                welcome.Show();
                //begin0.Visible = true;
                this.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
