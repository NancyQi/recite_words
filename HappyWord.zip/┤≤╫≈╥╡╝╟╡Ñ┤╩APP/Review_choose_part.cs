﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 大作业记单词APP
{
    public partial class Review_choose_part : Form
    {
        Account account0;
        public Review_choose_part()
        {
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            InitializeComponent();
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
        }
        public Review_choose_part(Account account)
        {
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            InitializeComponent();
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
            account0 = account;
        }

        private void Review_choose_part_Load(object sender, EventArgs e)
        {
            this.label1.Text = "用户" + account0.Name + ",请选择复习模式：";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            EnglishChinese englishChinese = new EnglishChinese(account0);
            englishChinese.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ChineseEnglish chineseEnglish = new ChineseEnglish(account0);
            chineseEnglish.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Writting writting = new Writting(account0);
            writting.Show();
            this.Close();
        }
    }
}
