﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.IO;
using System.Data.SqlClient;

namespace 大作业记单词APP
{
    public partial class Remember : Form
    {
        
        private int imagecount;
        private List<string> imagepaths = new List<string>();
        private int nowcount = 0;
        


        Account now_account;

        //int t = 0;
        public Remember()
        {
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
            InitializeComponent();
            TopMost = true;
            
        }
        public Remember(Account account)
        {
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            InitializeComponent();
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");
            TopMost = true;
            now_account = account;
            now_account.Word_number=nowcount;
            progressBar1.Maximum = now_account.plan_number;
            /*
            #region 从文件读取数据 
            

            //创建StreamReader 
            StreamReader sw = new StreamReader(".\\College_Grade4.txt", Encoding.Default);

            string content = sw.ReadToEnd();//把文件读完存给content
            string[] lines = content.Split('\n');//把读取好的文件分割为一行一行存给数组
            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
            con.Open();
            for (int i = 0; i < lines.Length; i++)
            {
                string[] words = lines[i].Trim().Split('\t');
                if (words.Length < 2)
                    continue;
               
                string sql = string.Format("insert into wordbook_4 (chinese,english) values('{0}','{1}')",
                        (words[1]), words[0]);
                SqlCommand sqlcm = new SqlCommand(sql, con);
                int result = 0;
                try
                {
                    result = sqlcm.ExecuteNonQuery();
                    if (result == 1)
                    {

                    }
                    else
                    {

                    }
                }
                catch
                {
                    MessageBox.Show("添加失败");
                }

                
            #endregion
        }
            con.Close();
            */
        }

        private void Remember_Load(object sender, EventArgs e)
        {
            progressBar1.Maximum = now_account.plan_number;

        }


        public void changeProgressBar()
        {
            try
            {
                progressBar1.Value++;
                double x = progressBar1.Value;

                Graphics g = this.progressBar1.CreateGraphics();
                string str = Math.Round(((x) * 100 / now_account.plan_number), 2).ToString("#0.00 ") + "%";
                Font font = new Font("Times New Roman", (float)10, FontStyle.Regular);
                PointF pt = new PointF(this.progressBar1.Width / 2 - 17, this.progressBar1.Height / 2 - 7);
                g.DrawString(str, font, Brushes.Blue, pt);
                label3.Text = "已经完成：" + x.ToString() + "  总共：" + now_account.plan_number.ToString();
            }
            catch (ArgumentOutOfRangeException)
            {
               // MessageBox.Show("successs", "完成", MessageBoxButtons.OKCancel);
            }


        }//进度条

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }



        private void timer1_Tick(object sender, EventArgs e)
        {
         
            string filePath = ".\\pictures";
            DirectoryInfo di = new DirectoryInfo(filePath);
            changeProgressBar();
            FileInfo[] arrFi = di.GetFiles();
            SortAsFileName(ref arrFi);

            foreach (FileInfo f in arrFi)
            {

                imagepaths.Add(f.FullName);
            }
            if (imagepaths.Count != 0)
            {
                imagecount = imagepaths.Count;
            }
            if (nowcount < imagecount)
            {
                this.pictureBox1.Image = ZoomPicture(Bitmap.FromFile(imagepaths[nowcount]), 100, 100);
                //nowcount++;
            }
            
            timer1.Interval = 1000;
          

            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
            con.Open();
            string sql = string.Format("select* from wordbook_4");
            string sql2 = string.Format("select* from review");
            SqlDataAdapter sad2 = new SqlDataAdapter(sql2, con);
            DataTable t2 = new DataTable();
            sad2.Fill(t2);
            SqlDataAdapter sad = new SqlDataAdapter(sql, con);
            DataTable t = new DataTable();
            sad.Fill(t);
            int thistag = 0;
            //MessageBox.Show((t.Rows.Count).ToString());
            if (nowcount < t.Rows.Count)
            {
                this.label1.Text = (string)((t.Rows)[nowcount]["english"]);
                this.label2.Text = (string)((t.Rows)[nowcount]["chinese"]);
                for (int j = 0; j < t2.Rows.Count; j++)
                {
                    string c = (string)((t.Rows)[nowcount]["chinese"]);
                    string en = (string)((t.Rows)[nowcount]["english"]);
                    if (c == (string)((t2.Rows)[j]["chinese"]) && en == (string)((t2.Rows)[j]["english"]))
                    {
                        thistag = 1;
                        break;
                    }
                }

                now_account.Word_number++;

                if (thistag == 0)
                {
                   

                    //插到review库
                    string sqlm = string.Format("insert into review(chinese,english,tag) values('{0}','{1}',1)",
                        (string)((t.Rows)[nowcount]["chinese"]), (string)((t.Rows)[nowcount]["english"]));
                    SqlCommand sqlcm = new SqlCommand(sqlm, con);
                    int result = 0;
                    try
                    {
                        result = sqlcm.ExecuteNonQuery();
                        if (result == 1)
                        {

                        }
                        else
                        {

                        }
                    }
                    catch
                    {
                        MessageBox.Show("添加失败");
                    }
                    
                }
                nowcount++;
            }
            

            con.Close();
            
        }


        // 按比例缩放图片
        public Image ZoomPicture(Image SourceImage, int TargetWidth, int TargetHeight)
        {
            int IntWidth; //新的图片宽
            int IntHeight; //新的图片高
            try
            {
                System.Drawing.Imaging.ImageFormat format = SourceImage.RawFormat;
                System.Drawing.Bitmap SaveImage = new System.Drawing.Bitmap(TargetWidth, TargetHeight);
                Graphics g = Graphics.FromImage(SaveImage);
                g.Clear(Color.White);


                if (SourceImage.Width > TargetWidth && SourceImage.Height <= TargetHeight)//宽度比目的图片宽度大，长度比目的图片长度小
                {
                    IntWidth = TargetWidth;
                    IntHeight = (IntWidth * SourceImage.Height) / SourceImage.Width;
                }
                else if (SourceImage.Width <= TargetWidth && SourceImage.Height > TargetHeight)//宽度比目的图片宽度小，长度比目的图片长度大
                {
                    IntHeight = TargetHeight;
                    IntWidth = (IntHeight * SourceImage.Width) / SourceImage.Height;
                }
                else if (SourceImage.Width <= TargetWidth && SourceImage.Height <= TargetHeight) //长宽比目的图片长宽都小
                {
                    IntHeight = SourceImage.Width;
                    IntWidth = SourceImage.Height;
                }
                else//长宽比目的图片的长宽都大
                {
                    IntWidth = TargetWidth;
                    IntHeight = (IntWidth * SourceImage.Height) / SourceImage.Width;
                    if (IntHeight > TargetHeight)//重新计算
                    {
                        IntHeight = TargetHeight;
                        IntWidth = (IntHeight * SourceImage.Width) / SourceImage.Height;
                    }
                }

                g.DrawImage(SourceImage, (TargetWidth - IntWidth) / 2, (TargetHeight - IntHeight) / 2, IntWidth, IntHeight);
                SourceImage.Dispose();

                return SaveImage;
            }
            catch (Exception ex)
            {

            }

            return null;
        }
        //按比例缩放图片
        private void SortAsFileName(ref FileInfo[] arrFi)
        {
            Array.Sort(arrFi, delegate (FileInfo x, FileInfo y) { return x.Name.CompareTo(y.Name); });
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            if (now_account.plan_number > now_account.Word_number)
            {
                MessageBox.Show("今日任务仍未完成，继续加油哟~");
            }
            else
            {
                PunchIn punchIn = new PunchIn(now_account);
                punchIn.Show();
                this.Close();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }
    }
}
