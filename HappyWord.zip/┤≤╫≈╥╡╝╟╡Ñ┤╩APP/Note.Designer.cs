﻿namespace 大作业记单词APP
{
    partial class Note
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Note));
            this.notes = new System.Windows.Forms.CheckedListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.selectall = new System.Windows.Forms.CheckBox();
            this.admit = new System.Windows.Forms.Button();
            this.newnote = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // notes
            // 
            this.notes.FormattingEnabled = true;
            this.notes.Location = new System.Drawing.Point(147, 273);
            this.notes.Name = "notes";
            this.notes.Size = new System.Drawing.Size(360, 254);
            this.notes.TabIndex = 0;
            this.notes.SelectedIndexChanged += new System.EventHandler(this.notes_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Location = new System.Drawing.Point(144, 161);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "请选择词书";
            // 
            // selectall
            // 
            this.selectall.AutoSize = true;
            this.selectall.Location = new System.Drawing.Point(274, 161);
            this.selectall.Name = "selectall";
            this.selectall.Size = new System.Drawing.Size(70, 22);
            this.selectall.TabIndex = 3;
            this.selectall.Text = "全选";
            this.selectall.UseVisualStyleBackColor = true;
            this.selectall.CheckedChanged += new System.EventHandler(this.selectall_CheckedChanged);
            // 
            // admit
            // 
            this.admit.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.admit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("admit.BackgroundImage")));
            this.admit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.admit.FlatAppearance.BorderSize = 0;
            this.admit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.admit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.admit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.admit.Location = new System.Drawing.Point(382, 134);
            this.admit.Margin = new System.Windows.Forms.Padding(0);
            this.admit.Name = "admit";
            this.admit.Size = new System.Drawing.Size(125, 75);
            this.admit.TabIndex = 4;
            this.admit.UseVisualStyleBackColor = false;
            this.admit.Click += new System.EventHandler(this.admit_Click);
            // 
            // newnote
            // 
            this.newnote.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.newnote.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("newnote.BackgroundImage")));
            this.newnote.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.newnote.FlatAppearance.BorderSize = 0;
            this.newnote.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.newnote.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.newnote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newnote.Location = new System.Drawing.Point(147, 586);
            this.newnote.Margin = new System.Windows.Forms.Padding(0);
            this.newnote.Name = "newnote";
            this.newnote.Size = new System.Drawing.Size(120, 70);
            this.newnote.TabIndex = 5;
            this.newnote.UseVisualStyleBackColor = false;
            this.newnote.Click += new System.EventHandler(this.newnote_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(387, 572);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 75);
            this.button1.TabIndex = 6;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Note
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(708, 844);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.newnote);
            this.Controls.Add(this.admit);
            this.Controls.Add(this.selectall);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.notes);
            this.Name = "Note";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Note";
            this.Load += new System.EventHandler(this.Note_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox notes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox selectall;
        private System.Windows.Forms.Button admit;
        private System.Windows.Forms.Button newnote;
        private System.Windows.Forms.Button button1;
    }
}