﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.VisualBasic;
using System.Runtime.Remoting.Channels;
using Microsoft.SqlServer;
namespace 大作业记单词APP
{

    public partial class Note : Form
    {
       
        public Note()
        {
            InitializeComponent();
            this.BackgroundImage = Image.FromFile(".\\bg.jpg");

            for (int i = 0; i < qnotes.Length; i++)
            {
                notes.Items.Add(qnotes[i]);
            }
            
        }
        public string[] qnotes = { "word", "hello", "choose" };
        
        public string newordenglish;
        public string newordchinese;
        private void notes_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void selectall_CheckedChanged(object sender, EventArgs e)
        {
            if (selectall.Checked)
            {
                for (int j = 0; j < notes.Items.Count; j++)
                {
                    notes.SetItemChecked(j, true);
                }
            }
            else
            {
                for (int j = 0; j < notes.Items.Count; j++)
                {
                    notes.SetItemChecked(j, false);
                }
            }
        }

        private void admit_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < notes.Items.Count; i++)
            {
                if (notes.GetItemChecked(i))
                {
                    for (int j = 0; j < qnotes.Length; j++)
                    {
                        if (qnotes[j] == notes.GetItemText(notes.Items[i]))
                        {
                            //加入数据库
                            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
                            con.Open();
                            if (qnotes[j] == "word") 
                            {
                                string sql = string.Format("insert into word values('{0}','{1}')", newordchinese, newordenglish);
                                SqlCommand sqlc = new SqlCommand(sql, con);
                                int result = 0;
                                try
                                {
                                    result = sqlc.ExecuteNonQuery();
                                    if(result==1)
                                    {
                                        MessageBox.Show("添加成功");
                                    }
                                    else
                                    {
                                        MessageBox.Show("添加失败");
                                    }
                                }
                                catch
                                {
                                    MessageBox.Show("添加失败");
                                }
                                con.Close();
                            }
                            else if (qnotes[j] == "hello")
                            {
                                string sql = string.Format("insert into hello values('{0}','{1}')", newordchinese, newordenglish);
                                SqlCommand sqlc = new SqlCommand(sql, con);
                                int result = 0;
                                try
                                {
                                    result = sqlc.ExecuteNonQuery();
                                    if (result == 1)
                                    {
                                        MessageBox.Show("添加成功");
                                    }
                                    else
                                    {
                                        MessageBox.Show("添加失败");
                                    }
                                }
                                catch
                                {
                                    MessageBox.Show("添加失败");
                                }
                                con.Close();
                            }
                            else if (qnotes[j] == "choose")
                            {
                                string sql = string.Format("insert into choose values('{0}','{1}')", newordchinese, newordenglish);
                                SqlCommand sqlc = new SqlCommand(sql, con);
                                int result = 0;
                                try
                                {
                                    result = sqlc.ExecuteNonQuery();
                                    if (result == 1)
                                    {
                                        MessageBox.Show("添加成功");
                                    }
                                    else
                                    {
                                        MessageBox.Show("添加失败");
                                    }
                                }
                                catch
                                {
                                    MessageBox.Show("添加失败");
                                }
                                con.Close();
                            }
                        }
                    }
                }
            }
            /*
            for (int j = 0; j < notes.Items.Count; j++)
            {
                notes.SetItemChecked(j, false);
            }
            */
        }

        private void newnote_Click(object sender, EventArgs e)
        {
            String inword = Interaction.InputBox("请输入新词书的名字", "名字", "", 100, 100);
            MessageBox.Show("创建成功！");
            SqlConnection con = new SqlConnection("server=DESKTOP-R4MRDG4;uid=sa;pwd=qiyuxin;database=Qnotes;");
            if (con.State == ConnectionState.Open)
                con.Close();
            string sql = "CREATE TABLE" + inword + "(chinese nvarchar(50),english nvarchar(50))";
            SqlCommand cmd = new SqlCommand(sql, con);
            try
            {
                cmd.ExecuteNonQuery();
                sql="insert into"+inword+ ("values('{0}', '{1}')", newordchinese, newordenglish);

            }
            catch
            {
                MessageBox.Show("添加失败");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Notebook n = new Notebook();
            n.Show();
            for (int i = 0; i < notes.Items.Count; i++)
            {
                if (notes.GetItemChecked(i))
                {
                    for (int j = 0; j < qnotes.Length; j++)
                    {
                        if (qnotes[j] == notes.GetItemText(notes.Items[i]))
                        {
                            n.bookname = qnotes[j];
                        }
                    }
                }
            }
            for (int j = 0; j < notes.Items.Count; j++)
            {
                notes.SetItemChecked(j, false);
            }
           
        }

        private void Note_Load(object sender, EventArgs e)
        {

        }
    }
}
